-- TODO: Scommentare in produzione

DROP TABLE IF EXISTS `{{PREFIX}}as_fullsync_queue`;
DROP TABLE IF EXISTS `{{PREFIX}}as_notifications`;
